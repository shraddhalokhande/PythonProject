import subprocess
import sys


def __isConda()-> bool:
    #TODO
    pass



def installModule(package):
    
    packageManager = "pip"

    if __isConda() == True:
        pass
        #TODO

     
 
    